(function () {

    var module = angular.module('app', []);

    module.component('direccion', {
        templateUrl: 'direccion.html',
        controllerAs: 'vm',
        require: {
            formulario: '^form',
        },
        bindings: {
            modelo: '=',
        },
        controller: function ($log) {
            var vm = this;
            

            vm.$onInit = function () {
                $log.info(this.formulario.$name);
            };

            vm.formularioo = vm.formulario.$name;
            
            vm.modelo = " modificado";
            vm.nomenclatura = [
                "Avenida",
                "Avenida Calle",
                "Autopista",
                "Avenida Carrera",
                "Bulevar",
                "Calle",
                "Carrera",
                "Carretera",
                "Circular",
                "Circunvalar",
                "Cuentas Corridas",
                "Diagonal",
                "Pasaje",
                "Paseo",
                "Peatonal",
                "Transversal",
                "Troncal",
                "Vía"
            ]
        }
    });

    module.component('contenedorDireccionUno', {
        templateUrl: 'contenedor.direccion.uno.html',
        controllerAs: 'vm',
        controller: function () {
            var vm = this;
            vm.modelo = " modificado";
            vm.cliente = {
                nombre: "Cliente",
                direccion: "A "
            }
        }
    });

    module.component('contenedorDireccionDos', {
        templateUrl: 'contenedor.direccion.dos.html',
        controllerAs: 'vm',
        controller: function () {
            var vm = this;
            vm.contacto = {
                nombre: "Contacto",
                direccion: "A "
            }
        }
    });
} ());